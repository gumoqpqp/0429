package p0429;

import java.util.Scanner;

public class exam05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.print("정숫값: ");
		int a = s.nextInt();
		System.out.println("입력받은 값입니다 : " + a );


	}

}
