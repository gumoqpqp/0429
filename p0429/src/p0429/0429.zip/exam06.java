package p0429;

import java.util.Scanner;

public class exam06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   Scanner	s = new Scanner(System.in);
		    int a;
		    

			System.out.print("정수를 입력 ; ");
			a = s.nextInt();
			
			int sum, sum1;
			sum=a+10;
			sum1=a-10;
  
		    System.out.println(sum); 
		    System.out.print(sum1);    

		   
	}

}
