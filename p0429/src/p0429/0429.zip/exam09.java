package p0429;

import java.util.Scanner;

public class exam09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner s = new Scanner(System.in);
	
	
	

	System.out.print("성: ");
	String sung= s.next();
	System.out.print("이름: ");
	String name= s.next();
	System.out.print("안녕하세요 "  +sung+name+  "씨");
	
	
	
	
	}

}
