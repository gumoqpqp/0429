package p0429;

import java.util.Scanner;

public class exam30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in); 
        System.out.print("숫자 입력 : "); 
        int num = s.nextInt(); 
       
        for (int i = num; i >= 0; i--) 
        { 
            System.out.println(i); 
          
            
       
        } 
    } 
}




