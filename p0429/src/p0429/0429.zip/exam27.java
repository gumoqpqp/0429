package p0429;

public class exam27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
