package p0429;

import java.util.Scanner;


public class exam23 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		
			    System.out.print("정수 a：");
			    int a = s.nextInt();       
			    System.out.print("정수 b：");
			    int b = s.nextInt(); 
			    
			 
			    int d;
			    if (a < b) {
			    	System.out.print("작은 값은" +a + "큰 값은" +b );
			    	
			    }
			    
			    else if (a < b) {
				    	System.out.print("작은 값은" +a + "큰 값은" +b );
			    }
			    	
		         else {
		        	System.out.print("두 값이 같습니다");
		        	
				    
		        }
		       

	}
}

