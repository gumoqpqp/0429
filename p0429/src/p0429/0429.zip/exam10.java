package p0429;

import java.util.Scanner;

public class exam10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		
		

		System.out.print("주소: ");
		String address= s.next();
		
		System.out.print("주소는 "  +address +  "입니다");
		
		

	}

}
