package p0429;

import java.util.Scanner;

public class exam15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		int a, b;
		 System.out.println("정수 입력");
		 a=s.nextInt();
		 System.out.println("정수 입력");
		 b=s.nextInt();	
		 
		 if ((a<b))
			 System.out.println("b가크다");
		 else
			 System.out.println("a가크다");
		 
		 
	}

}
