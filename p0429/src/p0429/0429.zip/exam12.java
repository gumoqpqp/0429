package p0429;

import java.util.Scanner;

public class exam12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int num1;
		
		System.out.print("정수값:");
		num1 = s.nextInt();
		
		System.out.println( Math.abs(num1));
		

	}
	
}
