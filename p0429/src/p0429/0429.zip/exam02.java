package p0429;

public class exam02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("이");
		System.out.println("지");
		System.out.println("원");
	}

}
