package p0429;

import java.util.Scanner;

public class exam25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
		
	    int i, num;
	 
	    System.out.printf ("몇개의 *를  표시할까요?: ");
	    num=s.nextInt();
	    
	    for (i=0; i<num; i++)
	 
	    System.out.printf ("*");
	 
	
	}

}
