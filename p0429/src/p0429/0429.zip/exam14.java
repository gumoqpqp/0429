package p0429;

import java.util.Scanner;

public class exam14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		

	       Scanner s = new Scanner(System.in);
	      
	       System.out.println("숫자입력");
	       int a=s.nextInt();
	      
	      
	      
	       if(a<0){
	    	   System.out.println("음수입니다");
	    	 }
	       else if(a>0){
	    	   System.out.println("양수입니다");
	       }
	    	   else if(a==0){
		    	   System.out.println("0입니다");
		    	   
	       
	  
	    	   
	       }
	}
}
