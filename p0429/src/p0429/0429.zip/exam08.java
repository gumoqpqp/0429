package p0429;

import java.util.Scanner;

public class exam08 {

	public static void main(String[] args) {
 Scanner s = new Scanner(System.in);
 
		double w;
		double h;
		double a;
		
        
		System.out.println("삼각형의 밑변: " ); 
		w=s.nextDouble();
		System.out.println("삼각혀의 높이: " );
		h=s.nextDouble();
		
		a=0.5*w*h;
					
		System.out.println("삼각형의 넓이"+a);
	
		
		}
	
		
		
	

	}


